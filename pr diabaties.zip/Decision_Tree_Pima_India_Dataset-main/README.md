# Decision_Tree_Pima_India_Dataset
Hands-on Practice for understanding Decision Tree 
